// Simple mobile menu toggle (you can expand later)
document.querySelector('.mobile-menu-btn').addEventListener('click', () => {
    alert("Mobile menu coming soon! For now, the site works great on phones.");
});

// Contact form submission (demo - shows alert)
document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert("Thank you! Your message has been received. We will contact you soon.");
    this.reset();
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        if (this.getAttribute('href') !== '#') {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});// Mobile menu toggle
const menuBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

menuBtn.addEventListener('click', () => {
  navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
});// Mobile menu toggle with slide-in effect
const menuBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

menuBtn.addEventListener('click', () => {
  navLinks.classList.toggle('show'); // add/remove the "show" class
});// Mobile menu toggle with slide-in effect
const menuBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

// Toggle the "show" class when hamburger icon is clicked
menuBtn.addEventListener('click', () => {
  navLinks.classList.toggle('show');
});

// Optional: Close menu when a link is clicked (better UX on mobile)
const navItems = document.querySelectorAll('.nav-links a');
navItems.forEach(item => {
  item.addEventListener('click', () => {
    navLinks.classList.remove('show');
  });
});